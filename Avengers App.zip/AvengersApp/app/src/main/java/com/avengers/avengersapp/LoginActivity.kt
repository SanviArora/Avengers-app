package com.avengers.avengersapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity()  {


    lateinit var etMobileNumber: EditText
    lateinit var etPassword:EditText
    lateinit var btnLogin:Button
    lateinit var txtForgotPassword:TextView
    lateinit var txtRegisterYourself:TextView

    val validMobileNumber="1234567890"
    val validPassword= arrayOf("Tony","Steve","Natasha","thanos")

    lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences=getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        val isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false)
        setContentView(R.layout.activity_loginwindow)
        if (isLoggedIn)
        {
            val intent=Intent(this@LoginActivity,MainActivity::class.java)
            startActivity(intent)
            finish()
        }


        setContentView(R.layout.activity_loginwindow)
        title="Login"

        etMobileNumber=findViewById(R.id.etMobileNumber)
        etPassword=findViewById(R.id.etPassword)
        btnLogin=findViewById(R.id.btnLogin)
        txtForgotPassword=findViewById(R.id.txtForgotPassword)
        txtRegisterYourself=findViewById(R.id.txtRegisterYourself)


        btnLogin.setOnClickListener {
            val mobileNumber = etMobileNumber.text.toString()
            val password = etPassword.text.toString()

            var nameOfAvenger = "Avenger"
            val intent=Intent(this@LoginActivity,MainActivity::class.java)


            if ((mobileNumber == validMobileNumber)) {
                if (password == validPassword[0]) {
                    nameOfAvenger = "Iron Man"

                    startActivity(intent)
                    savePreferences(nameOfAvenger)

                } else if (password == validPassword[1]) {
                    nameOfAvenger ="Captain America"

                    startActivity(intent)
                    savePreferences(nameOfAvenger)

                } else if (password == validPassword[2]) {
                    nameOfAvenger = "Black Widow"

                    startActivity(intent)
                    savePreferences(nameOfAvenger)
                } else if (password == validPassword[3]) {
                    nameOfAvenger = "Thanos"

                    startActivity(intent)
                    savePreferences(nameOfAvenger)
                }

            }

                else
                {
                    Toast.makeText(this@LoginActivity, "Incorrect credentials", Toast.LENGTH_LONG)
                        .show()
                }
            }

    }

    override fun onPause() {
        super.onPause()
        finish()
    }
    fun savePreferences(title:String)
    {
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("Title",title).apply()
    }


}